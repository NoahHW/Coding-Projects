package deliverySystem.models.deliveryman;



import java.util.ArrayList;
import java.util.List;

public class DeliveryManPageModel {
	
	private String DeliveryManUserName = "";
	
	public void setDMUserName(String username) {
		DeliveryManUserName=username;
	}
	public String getDMUserName() {
		return DeliveryManUserName;
	}
	
}
