package deliverySystem.models.deliveryman;

public class AcceptDeliveriesModel {
   
}
